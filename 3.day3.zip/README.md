# pepsi-clone
펩시골라 클론코딩

## 개발환경
- Chrome / Edge web browser
- visual studio code
- git
